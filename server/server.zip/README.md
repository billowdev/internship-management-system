### ฐานข้อมูลจังหวัดในประเทศไทย

ฐานข้อมูลจังหวัดในประเทศไทยมาจาก https://github.com/parsilver/thailand-provinces 
